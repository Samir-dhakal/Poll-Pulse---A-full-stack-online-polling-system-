package com.tillu.pollpulse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PollpulseApplicationTests {

	@Test
	void contextLoads() {
	}

}
