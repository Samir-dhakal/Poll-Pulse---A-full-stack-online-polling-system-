package com.tillu.pollpulse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PollpulseApplication {

	public static void main(String[] args) {
		SpringApplication.run(PollpulseApplication.class, args);
	}

}
